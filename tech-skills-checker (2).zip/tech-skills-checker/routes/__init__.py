"""
Flask Routes for Tech Skills Checker
Ye file saare routes define karti hai
"""

from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from models import db, User, Skill, UserSkill, SkillAnalysis, JobRecommendation
from scraper import scrape_job_skills
from datetime import datetime
from sqlalchemy import func

# Blueprint banaiye
auth_bp = Blueprint('auth', __name__)
main_bp = Blueprint('main', __name__)
api_bp = Blueprint('api', __name__, url_prefix='/api')


# ============================================================
# AUTHENTICATION ROUTES
# ============================================================

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """
    User registration page
    """
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validation
        if not username or not email or not password:
            flash('Saare fields fill karo!', 'error')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('Passwords match nahi ho rahe!', 'error')
            return render_template('register.html')
        
        # Check if user already exists
        if User.query.filter_by(username=username).first():
            flash('Username pehle se exist karta hai!', 'error')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email pehle se registered hai!', 'error')
            return render_template('register.html')
        
        # Create new user
        new_user = User(username=username, email=email)
        new_user.set_password(password)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! Ab login karo.', 'success')
            return redirect(url_for('auth.login'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error: {str(e)}', 'error')
            return render_template('register.html')
    
    return render_template('register.html')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """
    User login page
    """
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = request.form.get('remember', False)
        
        if not username or not password:
            flash('Username aur password dono chahiye!', 'error')
            return render_template('login.html')
        
        # Find user
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user, remember=remember)
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            flash(f'Welcome back, {user.username}!', 'success')
            
            # Redirect to next page if available
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('main.dashboard'))
        else:
            flash('Invalid username ya password!', 'error')
            return render_template('login.html')
    
    return render_template('login.html')


@auth_bp.route('/logout')
@login_required
def logout():
    """
    User logout
    """
    logout_user()
    flash('Successfully logged out!', 'success')
    return redirect(url_for('auth.login'))


# ============================================================
# MAIN ROUTES
# ============================================================

@main_bp.route('/')
def index():
    """
    Home page
    """
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return render_template('index.html')


@main_bp.route('/dashboard')
@login_required
def dashboard():
    """
    User dashboard
    """
    # User ki skills count karo
    user_skills_count = UserSkill.query.filter_by(user_id=current_user.id).count()
    
    # Recent analyses
    recent_analyses = SkillAnalysis.query.filter_by(user_id=current_user.id)\
                                         .order_by(SkillAnalysis.created_at.desc())\
                                         .limit(5).all()
    
    # Job recommendations
    job_recommendations = JobRecommendation.query.filter_by(user_id=current_user.id)\
                                                  .order_by(JobRecommendation.match_percentage.desc())\
                                                  .limit(5).all()
    
    # User's skills with proficiency
    user_skills = db.session.query(Skill, UserSkill.proficiency_level)\
                            .join(UserSkill, Skill.id == UserSkill.skill_id)\
                            .filter(UserSkill.user_id == current_user.id)\
                            .all()
    
    return render_template('dashboard.html',
                          user_skills_count=user_skills_count,
                          recent_analyses=recent_analyses,
                          job_recommendations=job_recommendations,
                          user_skills=user_skills)


@main_bp.route('/skills')
@login_required
def skills():
    """
    Skills management page
    """
    # Saare available skills
    all_skills = Skill.query.order_by(Skill.category, Skill.name).all()
    
    # User ki current skills
    user_skill_ids = [us.skill_id for us in UserSkill.query.filter_by(user_id=current_user.id).all()]
    
    # Skills by category
    skills_by_category = {}
    for skill in all_skills:
        if skill.category not in skills_by_category:
            skills_by_category[skill.category] = []
        skills_by_category[skill.category].append({
            'skill': skill,
            'has_skill': skill.id in user_skill_ids
        })
    
    return render_template('skills.html', skills_by_category=skills_by_category)


@main_bp.route('/analyze', methods=['GET', 'POST'])
@login_required
def analyze():
    """
    Job analysis page
    """
    if request.method == 'POST':
        job_title = request.form.get('job_title')
        
        if not job_title:
            flash('Job title enter karo!', 'error')
            return render_template('analyze.html')
        
        try:
            # Scrape job skills
            scraped_data = scrape_job_skills(job_title)
            
            # User ki current skills
            user_skills = db.session.query(Skill.name)\
                                    .join(UserSkill, Skill.id == UserSkill.skill_id)\
                                    .filter(UserSkill.user_id == current_user.id)\
                                    .all()
            user_skill_names = [s[0] for s in user_skills]
            
            # Match karo
            required_skills = scraped_data['skills']
            matching_skills = [s for s in required_skills if s in user_skill_names]
            missing_skills = [s for s in required_skills if s not in user_skill_names]
            
            match_percentage = (len(matching_skills) / len(required_skills) * 100) if required_skills else 0
            
            # Save analysis
            analysis = SkillAnalysis(
                user_id=current_user.id,
                job_title=job_title,
                required_skills=','.join(required_skills),
                matching_skills=','.join(matching_skills),
                missing_skills=','.join(missing_skills),
                match_percentage=match_percentage,
                total_jobs_analyzed=scraped_data['job_count']
            )
            db.session.add(analysis)
            
            # Save job recommendation
            recommendation = JobRecommendation(
                user_id=current_user.id,
                job_title=job_title,
                match_percentage=match_percentage,
                required_skills=','.join(required_skills),
                missing_skills=','.join(missing_skills)
            )
            db.session.add(recommendation)
            
            db.session.commit()
            
            return render_template('analyze_results.html',
                                  job_title=job_title,
                                  required_skills=required_skills,
                                  matching_skills=matching_skills,
                                  missing_skills=missing_skills,
                                  match_percentage=round(match_percentage, 2),
                                  jobs_analyzed=scraped_data['job_count'],
                                  sources=scraped_data['sources'])
            
        except Exception as e:
            flash(f'Error analyzing job: {str(e)}', 'error')
            return render_template('analyze.html')
    
    return render_template('analyze.html')


@main_bp.route('/recommendations')
@login_required
def recommendations():
    """
    Job recommendations page
    """
    # Saare recommendations
    job_recs = JobRecommendation.query.filter_by(user_id=current_user.id)\
                                      .order_by(JobRecommendation.match_percentage.desc())\
                                      .all()
    
    return render_template('recommendations.html', recommendations=job_recs)


@main_bp.route('/profile')
@login_required
def profile():
    """
    User profile page
    """
    # Stats calculate karo
    total_skills = UserSkill.query.filter_by(user_id=current_user.id).count()
    total_analyses = SkillAnalysis.query.filter_by(user_id=current_user.id).count()
    
    # Average match percentage
    avg_match = db.session.query(func.avg(SkillAnalysis.match_percentage))\
                          .filter_by(user_id=current_user.id).scalar() or 0
    
    # Skills by proficiency
    beginner = UserSkill.query.filter_by(user_id=current_user.id, proficiency_level='Beginner').count()
    intermediate = UserSkill.query.filter_by(user_id=current_user.id, proficiency_level='Intermediate').count()
    advanced = UserSkill.query.filter_by(user_id=current_user.id, proficiency_level='Advanced').count()
    expert = UserSkill.query.filter_by(user_id=current_user.id, proficiency_level='Expert').count()
    
    return render_template('profile.html',
                          total_skills=total_skills,
                          total_analyses=total_analyses,
                          avg_match=round(avg_match, 2),
                          beginner=beginner,
                          intermediate=intermediate,
                          advanced=advanced,
                          expert=expert)


# ============================================================
# API ROUTES
# ============================================================

@api_bp.route('/add-skill', methods=['POST'])
@login_required
def add_skill():
    """
    Add skill to user profile (AJAX)
    """
    data = request.get_json()
    skill_id = data.get('skill_id')
    proficiency = data.get('proficiency', 'Beginner')
    
    if not skill_id:
        return jsonify({'success': False, 'message': 'Skill ID required!'}), 400
    
    # Check if skill exists
    skill = Skill.query.get(skill_id)
    if not skill:
        return jsonify({'success': False, 'message': 'Skill not found!'}), 404
    
    # Check if already added
    existing = UserSkill.query.filter_by(user_id=current_user.id, skill_id=skill_id).first()
    if existing:
        return jsonify({'success': False, 'message': 'Skill already added!'}), 400
    
    # Add skill
    user_skill = UserSkill(
        user_id=current_user.id,
        skill_id=skill_id,
        proficiency_level=proficiency
    )
    
    try:
        db.session.add(user_skill)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Skill added successfully!'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500


@api_bp.route('/remove-skill', methods=['POST'])
@login_required
def remove_skill():
    """
    Remove skill from user profile (AJAX)
    """
    data = request.get_json()
    skill_id = data.get('skill_id')
    
    if not skill_id:
        return jsonify({'success': False, 'message': 'Skill ID required!'}), 400
    
    user_skill = UserSkill.query.filter_by(user_id=current_user.id, skill_id=skill_id).first()
    
    if not user_skill:
        return jsonify({'success': False, 'message': 'Skill not found!'}), 404
    
    try:
        db.session.delete(user_skill)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Skill removed successfully!'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500


@api_bp.route('/update-proficiency', methods=['POST'])
@login_required
def update_proficiency():
    """
    Update skill proficiency (AJAX)
    """
    data = request.get_json()
    skill_id = data.get('skill_id')
    proficiency = data.get('proficiency')
    
    if not skill_id or not proficiency:
        return jsonify({'success': False, 'message': 'Skill ID and proficiency required!'}), 400
    
    user_skill = UserSkill.query.filter_by(user_id=current_user.id, skill_id=skill_id).first()
    
    if not user_skill:
        return jsonify({'success': False, 'message': 'Skill not found!'}), 404
    
    try:
        user_skill.proficiency_level = proficiency
        db.session.commit()
        return jsonify({'success': True, 'message': 'Proficiency updated!'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500