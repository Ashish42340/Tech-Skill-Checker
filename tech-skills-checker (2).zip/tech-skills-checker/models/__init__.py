"""
Database Models for Tech Skills Checker
Ye file database tables define karti hai
"""

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

# Initialize SQLAlchemy
db = SQLAlchemy()


class User(UserMixin, db.Model):
    """
    User model - Stores user account information
    """
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Relationships
    skills = db.relationship('UserSkill', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    analyses = db.relationship('SkillAnalysis', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    recommendations = db.relationship('JobRecommendation', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if password matches"""
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'


class Skill(db.Model):
    """
    Skill model - Stores all available tech skills
    """
    __tablename__ = 'skills'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False, index=True)
    category = db.Column(db.String(50), nullable=False, index=True)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user_skills = db.relationship('UserSkill', backref='skill', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Skill {self.name}>'


class UserSkill(db.Model):
    """
    UserSkill model - Links users with their skills and proficiency levels
    """
    __tablename__ = 'user_skills'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    skill_id = db.Column(db.Integer, db.ForeignKey('skills.id'), nullable=False)
    proficiency_level = db.Column(db.String(20), default='Beginner')  # Beginner, Intermediate, Advanced, Expert
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Composite unique constraint
    __table_args__ = (db.UniqueConstraint('user_id', 'skill_id', name='_user_skill_uc'),)
    
    def __repr__(self):
        return f'<UserSkill user_id={self.user_id} skill_id={self.skill_id}>'


class SkillAnalysis(db.Model):
    """
    SkillAnalysis model - Stores job analysis results
    """
    __tablename__ = 'skill_analyses'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    job_title = db.Column(db.String(200), nullable=False)
    required_skills = db.Column(db.Text)  # Comma-separated
    matching_skills = db.Column(db.Text)  # Comma-separated
    missing_skills = db.Column(db.Text)  # Comma-separated
    match_percentage = db.Column(db.Float, default=0.0)
    total_jobs_analyzed = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<SkillAnalysis {self.job_title} - {self.match_percentage}%>'


class JobRecommendation(db.Model):
    """
    JobRecommendation model - Stores job recommendations for users
    """
    __tablename__ = 'job_recommendations'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    job_title = db.Column(db.String(200), nullable=False)
    match_percentage = db.Column(db.Float, default=0.0)
    required_skills = db.Column(db.Text)  # Comma-separated
    missing_skills = db.Column(db.Text)  # Comma-separated
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<JobRecommendation {self.job_title} - {self.match_percentage}%>'